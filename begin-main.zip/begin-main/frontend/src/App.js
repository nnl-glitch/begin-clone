import React, { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from "react-router-dom";
import { Toaster } from "sonner";
import "@/App.css";
import Studio from "@/pages/Studio";
import Welcome from "@/pages/Welcome";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import AuthCallback from "@/pages/AuthCallback";
import ForgotPassword from "@/pages/ForgotPassword";
import ResetPassword from "@/pages/ResetPassword";
import { SettingsProvider } from "@/lib/settings";
import { StudioProvider } from "@/lib/studio";
import { AuthProvider, useAuth } from "@/lib/auth";
import { WelcomeIntro } from "@/components/WelcomeIntro";

const WELCOME_SEEN_KEY = "scribecraft_welcome_seen";

function ProtectedRoute({ children }) {
  const { user } = useAuth();
  if (user === null) {
    // still checking session
    return (
      <div
        className="min-h-screen w-full flex items-center justify-center"
        style={{ background: "var(--sc-bg-app)", color: "var(--sc-text-secondary)" }}
        data-testid="auth-checking"
      >
        <p className="font-serif-reader text-xl italic">…</p>
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

/**
 * The entry gate. On first visit it plays the "Welcome to Begin." animation,
 * then bridges the writer into /write (if a session already exists) or /login.
 * After the first visit the welcome flag is set and this component becomes a
 * silent redirect.
 */
function EntryGate() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [showIntro, setShowIntro] = useState(() => {
    try { return !localStorage.getItem(WELCOME_SEEN_KEY); }
    catch { return false; }
  });

  // If the welcome has already been seen, route immediately based on auth
  // state. `user === null` means we're still checking, so wait.
  useEffect(() => {
    if (showIntro) return;
    if (user === null) return;
    navigate(user ? "/write" : "/login", { replace: true });
  }, [showIntro, user, navigate]);

  const finishIntro = () => {
    try { localStorage.setItem(WELCOME_SEEN_KEY, "1"); } catch (_) {}
    setShowIntro(false);
  };

  return (
    <div className="min-h-screen w-full" style={{ background: "var(--sc-bg-app)" }}>
      {showIntro && <WelcomeIntro onDone={finishIntro} />}
    </div>
  );
}

function AppRouter() {
  const location = useLocation();
  // Handle OAuth return anywhere the fragment lands. Synchronous check
  // during render prevents race conditions with ProtectedRoute.
  // - Emergent-managed flow lands with `#session_id=…` in the hash
  // - Standard Google OAuth (post-migration) lands at /auth/google with
  //   `?code=…&state=…` in the query
  if (location.hash?.includes("session_id=")) {
    return <AuthCallback />;
  }
  if (location.pathname === "/auth/google" && location.search.includes("code=")) {
    return <AuthCallback />;
  }
  return (
    <Routes>
      <Route path="/" element={<EntryGate />} />
      <Route path="/about" element={<Welcome />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route
        path="/write"
        element={
          <ProtectedRoute>
            <StudioProvider>
              <Studio />
            </StudioProvider>
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}

function App() {
  return (
    <SettingsProvider>
      <AuthProvider>
        <div className="App">
          <BrowserRouter>
            <AppRouter />
          </BrowserRouter>
          <Toaster
            position="bottom-right"
            toastOptions={{
              style: {
                background: "var(--sc-bg-sheet)",
                color: "var(--sc-text-primary)",
                border: "1px solid var(--sc-border)",
                fontFamily: "'Plus Jakarta Sans', sans-serif",
              },
            }}
          />
        </div>
      </AuthProvider>
    </SettingsProvider>
  );
}

export default App;
