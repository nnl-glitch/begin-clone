import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { useAuth, readableAuthError } from "../lib/auth";

export default function Register() {
  const { register, loginWithGoogle, loginAsGuest } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }
    setBusy(true);
    try {
      await register(email.trim().toLowerCase(), password, name.trim() || null);
      navigate("/write");
    } catch (err) {
      setError(readableAuthError(err));
    } finally {
      setBusy(false);
    }
  };

  const guest = async () => {
    setError("");
    setBusy(true);
    try {
      await loginAsGuest();
      navigate("/write");
    } catch (err) {
      setError(readableAuthError(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center px-6 py-16"
      style={{ background: "var(--sc-bg-app)", color: "var(--sc-text-primary)" }}
      data-testid="register-page"
    >
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-10">
          <h1 className="font-serif-reader text-5xl leading-none" data-testid="register-heading">
            Begin
          </h1>
          <p className="mt-3 italic text-sm" style={{ color: "var(--sc-text-secondary)" }}>
            begin the story only you can tell
          </p>
        </div>

        <button
          type="button"
          onClick={loginWithGoogle}
          className="w-full py-3.5 rounded-full font-serif-reader text-base transition hover:-translate-y-0.5 flex items-center justify-center gap-3"
          style={{ background: "#EFE7D6", color: "#1A1918" }}
          data-testid="register-google-btn"
        >
          Sign up with Google
        </button>

        <div className="my-6 flex items-center gap-4 text-xs uppercase tracking-widest" style={{ color: "var(--sc-text-secondary)" }}>
          <span className="h-px flex-1" style={{ background: "var(--sc-border)" }} />
          <span>or with email</span>
          <span className="h-px flex-1" style={{ background: "var(--sc-border)" }} />
        </div>

        <form onSubmit={submit} className="space-y-4" data-testid="register-form">
          <div>
            <label className="text-[10px] uppercase tracking-widest font-semibold block mb-1.5" style={{ color: "var(--sc-text-secondary)" }}>
              Pen name (optional)
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="What should Jupiter call you?"
              className="w-full px-4 py-3 rounded-md border bg-transparent"
              style={{ borderColor: "var(--sc-border)", color: "var(--sc-text-primary)" }}
              data-testid="register-name-input"
            />
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-widest font-semibold block mb-1.5" style={{ color: "var(--sc-text-secondary)" }}>
              Email
            </label>
            <input
              type="email"
              required
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-md border bg-transparent"
              style={{ borderColor: "var(--sc-border)", color: "var(--sc-text-primary)" }}
              data-testid="register-email-input"
            />
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-widest font-semibold block mb-1.5" style={{ color: "var(--sc-text-secondary)" }}>
              Password (6+ characters)
            </label>
            <input
              type="password"
              required
              minLength={6}
              autoComplete="new-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-md border bg-transparent"
              style={{ borderColor: "var(--sc-border)", color: "var(--sc-text-primary)" }}
              data-testid="register-password-input"
            />
          </div>

          {error && (
            <p className="text-sm" style={{ color: "#E85D75" }} data-testid="register-error">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={busy || !email || !password}
            className="w-full py-3.5 rounded-full font-serif-reader text-base transition disabled:opacity-50"
            style={{ background: "#EFE7D6", color: "#1A1918" }}
            data-testid="register-submit-btn"
          >
            {busy ? "Creating…" : "Create account"}
          </button>
        </form>

        <p className="mt-8 text-center text-sm" style={{ color: "var(--sc-text-secondary)" }}>
          Already have one?{" "}
          <Link to="/login" className="underline font-medium" style={{ color: "var(--sc-text-primary)" }} data-testid="go-to-login-link">
            Sign in
          </Link>
        </p>

        <button
          type="button"
          onClick={guest}
          disabled={busy}
          className="mt-6 w-full py-2 text-sm underline disabled:opacity-40"
          style={{ color: "var(--sc-text-secondary)" }}
          data-testid="guest-continue-btn"
        >
          Continue without an account
        </button>
      </motion.div>
    </div>
  );
}
