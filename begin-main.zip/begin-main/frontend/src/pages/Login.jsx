import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { useAuth, readableAuthError } from "../lib/auth";

export default function Login() {
  const { login, loginWithGoogle, loginAsGuest } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      await login(email.trim().toLowerCase(), password);
      navigate("/write");
    } catch (err) {
      setError(readableAuthError(err));
    } finally {
      setBusy(false);
    }
  };

  const guest = async () => {
    setError("");
    setBusy(true);
    try {
      await loginAsGuest();
      navigate("/write");
    } catch (err) {
      setError(readableAuthError(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center px-6 py-16"
      style={{ background: "var(--sc-bg-app)", color: "var(--sc-text-primary)" }}
      data-testid="login-page"
    >
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-10">
          <h1 className="font-serif-reader text-5xl leading-none" data-testid="login-heading">
            Begin
          </h1>
          <p className="mt-3 italic text-sm" style={{ color: "var(--sc-text-secondary)" }}>
            welcome back, keep the world going
          </p>
        </div>

        <button
          type="button"
          onClick={loginWithGoogle}
          className="w-full py-3.5 rounded-full font-serif-reader text-base transition hover:-translate-y-0.5 flex items-center justify-center gap-3 border"
          style={{ background: "#EFE7D6", color: "#1A1918", borderColor: "transparent" }}
          data-testid="google-login-btn"
        >
          <GoogleIcon /> Continue with Google
        </button>

        <div className="my-6 flex items-center gap-4 text-xs uppercase tracking-widest" style={{ color: "var(--sc-text-secondary)" }}>
          <span className="h-px flex-1" style={{ background: "var(--sc-border)" }} />
          <span>or with email</span>
          <span className="h-px flex-1" style={{ background: "var(--sc-border)" }} />
        </div>

        <form onSubmit={submit} className="space-y-4" data-testid="login-form">
          <FormField label="Email">
            <input
              type="email"
              required
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-md border bg-transparent"
              style={{ borderColor: "var(--sc-border)", color: "var(--sc-text-primary)" }}
              data-testid="login-email-input"
            />
          </FormField>
          <FormField label="Password">
            <input
              type="password"
              required
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-md border bg-transparent"
              style={{ borderColor: "var(--sc-border)", color: "var(--sc-text-primary)" }}
              data-testid="login-password-input"
            />
          </FormField>

          {error && (
            <p className="text-sm" style={{ color: "#E85D75" }} data-testid="login-error">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={busy || !email || !password}
            className="w-full py-3.5 rounded-full font-serif-reader text-base transition disabled:opacity-50"
            style={{ background: "#EFE7D6", color: "#1A1918" }}
            data-testid="login-submit-btn"
          >
            {busy ? "Signing in…" : "Sign in"}
          </button>
        </form>

        <p className="mt-8 text-center text-sm" style={{ color: "var(--sc-text-secondary)" }}>
          New here?{" "}
          <Link to="/register" className="underline font-medium" style={{ color: "var(--sc-text-primary)" }} data-testid="go-to-register-link">
            Create an account
          </Link>
        </p>
        <p className="mt-3 text-center text-xs" style={{ color: "var(--sc-text-secondary)" }}>
          <Link to="/forgot-password" className="underline" data-testid="go-to-forgot-link">
            Forgot password?
          </Link>
          <span className="mx-2">·</span>
          <Link to="/about" data-testid="back-to-landing-link">About Begin</Link>
        </p>

        <button
          type="button"
          onClick={guest}
          disabled={busy}
          className="mt-6 w-full py-2 text-sm underline disabled:opacity-40"
          style={{ color: "var(--sc-text-secondary)" }}
          data-testid="guest-continue-btn"
        >
          Continue without an account
        </button>
      </motion.div>
    </div>
  );
}

function FormField({ label, children }) {
  return (
    <div>
      <label className="text-[10px] uppercase tracking-widest font-semibold block mb-1.5" style={{ color: "var(--sc-text-secondary)" }}>
        {label}
      </label>
      {children}
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
      <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.5l6.7-6.7C35.6 2.7 30.1 0 24 0 14.7 0 6.7 5.4 2.9 13.2l7.9 6.1C12.6 13.5 17.9 9.5 24 9.5z" />
      <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.2-.4-4.7H24v9h12.7c-.5 3-2.2 5.6-4.7 7.3l7.6 5.9c4.4-4.1 7-10.1 7-17.5z" />
      <path fill="#FBBC05" d="M10.8 28.7c-.5-1.4-.8-3-.8-4.7s.3-3.3.8-4.7l-7.9-6.1C1.1 16.6 0 20.2 0 24s1.1 7.4 2.9 10.8l7.9-6.1z" />
      <path fill="#34A853" d="M24 48c6.1 0 11.3-2 15.1-5.5l-7.6-5.9c-2.1 1.4-4.8 2.2-7.5 2.2-6.1 0-11.4-4-13.2-9.8l-7.9 6.1C6.7 42.6 14.7 48 24 48z" />
    </svg>
  );
}
