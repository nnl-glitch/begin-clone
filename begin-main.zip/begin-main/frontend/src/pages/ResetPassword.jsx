import React, { useState, useEffect } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { api } from "../lib/api";
import { useAuth, readableAuthError } from "../lib/auth";

export default function ResetPassword() {
  const { setUser } = useAuth();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const token = params.get("token") || "";
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!token) setError("This reset link is missing its token.");
  }, [token]);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (password.length < 6) return setError("Password must be at least 6 characters");
    if (password !== confirm) return setError("Passwords don't match");
    setBusy(true);
    try {
      const { data } = await api.post("/auth/reset-password", {
        token,
        new_password: password,
      });
      setUser(data.user);
      navigate("/write", { replace: true });
    } catch (err) {
      setError(readableAuthError(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center px-6 py-16"
      style={{ background: "var(--sc-bg-app)", color: "var(--sc-text-primary)" }}
      data-testid="reset-page"
    >
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-10">
          <h1 className="font-serif-reader text-5xl leading-none" data-testid="reset-heading">
            New key
          </h1>
          <p className="mt-3 italic text-sm" style={{ color: "var(--sc-text-secondary)" }}>
            set a password and we'll drop you back in
          </p>
        </div>

        <form onSubmit={submit} className="space-y-4" data-testid="reset-form">
          <div>
            <label className="text-[10px] uppercase tracking-widest font-semibold block mb-1.5" style={{ color: "var(--sc-text-secondary)" }}>
              New password (6+ chars)
            </label>
            <input
              type="password"
              required
              minLength={6}
              autoComplete="new-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-md border bg-transparent"
              style={{ borderColor: "var(--sc-border)", color: "var(--sc-text-primary)" }}
              data-testid="reset-password-input"
            />
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-widest font-semibold block mb-1.5" style={{ color: "var(--sc-text-secondary)" }}>
              Confirm password
            </label>
            <input
              type="password"
              required
              minLength={6}
              autoComplete="new-password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              className="w-full px-4 py-3 rounded-md border bg-transparent"
              style={{ borderColor: "var(--sc-border)", color: "var(--sc-text-primary)" }}
              data-testid="reset-confirm-input"
            />
          </div>

          {error && (
            <p className="text-sm" style={{ color: "#E85D75" }} data-testid="reset-error">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={busy || !password || !confirm || !token}
            className="w-full py-3.5 rounded-full font-serif-reader text-base transition disabled:opacity-50"
            style={{ background: "#EFE7D6", color: "#1A1918" }}
            data-testid="reset-submit-btn"
          >
            {busy ? "Resetting…" : "Reset password"}
          </button>
        </form>

        <p className="mt-8 text-center text-sm" style={{ color: "var(--sc-text-secondary)" }}>
          <Link to="/login" className="underline" style={{ color: "var(--sc-text-primary)" }} data-testid="reset-back-to-login-link">
            ← Back to sign in
          </Link>
        </p>
      </motion.div>
    </div>
  );
}
