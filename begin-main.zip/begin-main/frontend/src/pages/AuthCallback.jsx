import React, { useEffect, useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";

export default function AuthCallback() {
  const location = useLocation();
  const navigate = useNavigate();
  const { setUser } = useAuth();
  const hasProcessed = useRef(false);

  useEffect(() => {
    if (hasProcessed.current) return;
    hasProcessed.current = true;

    // Path 1: Emergent-managed flow — session_id in the hash.
    const hash = location.hash || window.location.hash || "";
    const hashMatch = hash.match(/session_id=([^&]+)/);
    if (hashMatch) {
      const sessionId = decodeURIComponent(hashMatch[1]);
      (async () => {
        try {
          const { data } = await api.post("/auth/google/session", { session_id: sessionId });
          window.history.replaceState(null, "", window.location.pathname);
          setUser(data.user);
          navigate("/write", { replace: true });
        } catch (err) {
          console.error("google session exchange failed:", err);
          navigate("/login", { replace: true });
        }
      })();
      return;
    }

    // Path 2: Standard Google OAuth (post-migration) — ?code=&state= in query.
    const params = new URLSearchParams(location.search || window.location.search || "");
    const code = params.get("code");
    const state = params.get("state");
    if (code && state) {
      // REMINDER: DO NOT HARDCODE THE URL, OR ADD ANY FALLBACKS OR REDIRECT URLS, THIS BREAKS THE AUTH
      const redirectUri = window.location.origin + "/auth/google";
      (async () => {
        try {
          const { data } = await api.post("/auth/google/callback", { code, state, redirect_uri: redirectUri });
          window.history.replaceState(null, "", "/");
          setUser(data.user);
          navigate("/write", { replace: true });
        } catch (err) {
          console.error("google oauth callback failed:", err);
          navigate("/login", { replace: true });
        }
      })();
      return;
    }

    navigate("/login", { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center"
      style={{ background: "var(--sc-bg-app)", color: "var(--sc-text-primary)" }}
      data-testid="auth-callback"
    >
      <p className="font-serif-reader text-2xl italic" style={{ color: "var(--sc-text-secondary)" }}>
        letting you in…
      </p>
    </div>
  );
}
