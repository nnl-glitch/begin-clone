import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { api } from "../lib/api";
import { readableAuthError } from "../lib/auth";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);
  const [resetLink, setResetLink] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const { data } = await api.post("/auth/forgot-password", { email: email.trim().toLowerCase() });
      setSent(true);
      if (data.reset_link) {
        setResetLink(data.reset_link);
      }
    } catch (err) {
      setError(readableAuthError(err));
    } finally {
      setBusy(false);
    }
  };

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(resetLink);
      toast.success("Reset link copied");
    } catch (_) {}
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center px-6 py-16"
      style={{ background: "var(--sc-bg-app)", color: "var(--sc-text-primary)" }}
      data-testid="forgot-page"
    >
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-10">
          <h1 className="font-serif-reader text-5xl leading-none" data-testid="forgot-heading">
            Lost the key
          </h1>
          <p className="mt-3 italic text-sm" style={{ color: "var(--sc-text-secondary)" }}>
            we'll help you back into your world
          </p>
        </div>

        {!sent ? (
          <form onSubmit={submit} className="space-y-4" data-testid="forgot-form">
            <div>
              <label className="text-[10px] uppercase tracking-widest font-semibold block mb-1.5" style={{ color: "var(--sc-text-secondary)" }}>
                Email
              </label>
              <input
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-md border bg-transparent"
                style={{ borderColor: "var(--sc-border)", color: "var(--sc-text-primary)" }}
                data-testid="forgot-email-input"
              />
            </div>

            {error && (
              <p className="text-sm" style={{ color: "#E85D75" }} data-testid="forgot-error">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={busy || !email}
              className="w-full py-3.5 rounded-full font-serif-reader text-base transition disabled:opacity-50"
              style={{ background: "#EFE7D6", color: "#1A1918" }}
              data-testid="forgot-submit-btn"
            >
              {busy ? "Sending…" : "Send reset link"}
            </button>
          </form>
        ) : (
          <div className="space-y-4" data-testid="forgot-sent">
            <p className="text-sm leading-relaxed" style={{ color: "var(--sc-text-primary)" }}>
              If <span className="italic">{email}</span> is registered, a reset link is on its way.
              Check your inbox — the link is valid for one hour.
            </p>
            {resetLink && (
              <div
                className="rounded-md border p-4 text-xs break-all"
                style={{ borderColor: "var(--sc-border)", color: "var(--sc-text-secondary)" }}
                data-testid="forgot-dev-link-block"
              >
                <p className="uppercase tracking-widest text-[10px] mb-2" style={{ color: "var(--sc-text-secondary)" }}>
                  Dev preview — email isn't wired yet
                </p>
                <a href={resetLink} className="underline" style={{ color: "var(--sc-text-primary)" }} data-testid="forgot-dev-link">
                  {resetLink}
                </a>
                <button
                  type="button"
                  onClick={copyLink}
                  className="mt-3 block w-full py-2 rounded-md border text-xs"
                  style={{ borderColor: "var(--sc-border)", color: "var(--sc-text-primary)" }}
                  data-testid="forgot-copy-link-btn"
                >
                  Copy link
                </button>
              </div>
            )}
          </div>
        )}

        <p className="mt-8 text-center text-sm" style={{ color: "var(--sc-text-secondary)" }}>
          <Link to="/login" className="underline" style={{ color: "var(--sc-text-primary)" }} data-testid="back-to-login-link">
            ← Back to sign in
          </Link>
        </p>
      </motion.div>
    </div>
  );
}
