import React from "react";
import { Sidebar } from "../components/Sidebar";
import { Editor } from "../components/Editor";
import { TopBar } from "../components/TopBar";
import { AccessibilityDrawer } from "../components/AccessibilityDrawer";
import { PomodoroTimer } from "../components/PomodoroTimer";
import { ModeWorkspace } from "../components/ModeWorkspace";
import { Home } from "../components/Home";
import { useStudio } from "../lib/studio";

export default function Studio() {
  const { showSidebar, setShowSidebar, activeMode, activePage } = useStudio();

  const renderMain = () => {
    if (activeMode) return <ModeWorkspace />;
    if (activePage) return <Editor />;
    return <Home />;
  };

  return (
    <div
      className="h-screen w-full paper-grain flex flex-col overflow-hidden"
      style={{ background: "var(--sc-bg-app)", color: "var(--sc-text-primary)" }}
      data-testid="studio-root"
    >
      <TopBar />
      <div className="flex-1 min-h-0 flex w-full relative">
        {showSidebar && <Sidebar />}
        <main className="flex-1 min-w-0 flex flex-col overflow-hidden">
          {renderMain()}
        </main>
        {showSidebar && (
          <button
            aria-label="Close sidebar"
            onClick={() => setShowSidebar(false)}
            className="md:hidden fixed inset-0 top-16 z-20 bg-black/40"
            data-testid="mobile-backdrop"
          />
        )}
      </div>
      <AccessibilityDrawer />
      <PomodoroTimer />
    </div>
  );
}
