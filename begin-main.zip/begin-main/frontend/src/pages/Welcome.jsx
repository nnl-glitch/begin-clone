import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion, useReducedMotion } from "framer-motion";
import { Feather, Sparkles, Focus, Timer, Users, ShieldCheck, ArrowRight } from "lucide-react";
import { useAuth } from "../lib/auth";

const FEATURES = [
  {
    icon: <Sparkles className="w-4 h-4" />,
    title: "Meet Jupiter",
    body: "A literary partner that analyzes, revises, interprets & continues — with zero moralizing.",
  },
  {
    icon: <Users className="w-4 h-4" />,
    title: "Character Evolution",
    body: "Track how each character shifts chapter by chapter with sliders and stage labels.",
  },
  {
    icon: <Focus className="w-4 h-4" />,
    title: "Focus Modes",
    body: "Paragraph & line spotlights, distraction-free canvas, sensory-safe paper themes.",
  },
  {
    icon: <Timer className="w-4 h-4" />,
    title: "ADHD-Friendly Timer",
    body: "Gentle Pomodoro sprints with non-jarring break prompts. No aggressive dings.",
  },
  {
    icon: <ShieldCheck className="w-4 h-4" />,
    title: "Sync-Everywhere Autosave",
    body: "Every keystroke saved. Every reply archived. Nothing to repeat, ever.",
  },
  {
    icon: <Feather className="w-4 h-4" />,
    title: "Explicit-Friendly",
    body: "Romance, horror, erotica, dark fantasy — treated as craft, not something to sanitize.",
  },
];

const FULL_TAGLINE = "Where stories aren\u2019t sanitized.";

export default function Welcome() {
  const reduced = useReducedMotion();
  const [typed, setTyped] = useState(reduced ? FULL_TAGLINE : "");
  const { loginAsGuest } = useAuth();
  const navigate = useNavigate();
  const [guestBusy, setGuestBusy] = useState(false);

  const startAsGuest = async () => {
    setGuestBusy(true);
    try {
      await loginAsGuest();
      navigate("/write");
    } catch (_) {
      // fall back to normal login flow
      navigate("/login");
    } finally {
      setGuestBusy(false);
    }
  };

  useEffect(() => {
    if (reduced) return;
    let i = 0;
    const id = setInterval(() => {
      i += 1;
      setTyped(FULL_TAGLINE.slice(0, i));
      if (i >= FULL_TAGLINE.length) clearInterval(id);
    }, 55);
    return () => clearInterval(id);
  }, [reduced]);

  const container = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.08, delayChildren: 0.4 } },
  };
  const item = {
    hidden: { opacity: 0, y: 10 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
  };

  return (
    <div
      className="min-h-screen w-full paper-grain relative overflow-hidden"
      style={{ background: "var(--sc-bg-app)", color: "var(--sc-text-primary)" }}
      data-testid="welcome-root"
    >
      {/* Ambient blobs */}
      <motion.div
        aria-hidden
        className="absolute -top-24 -left-16 w-[420px] h-[420px] rounded-full blur-3xl opacity-40"
        style={{ background: "var(--sc-accent-primary)" }}
        initial={{ scale: 0.6, opacity: 0 }}
        animate={reduced ? {} : { scale: [0.6, 1, 0.9], opacity: [0, 0.35, 0.3] }}
        transition={{ duration: 8, repeat: Infinity, repeatType: "mirror" }}
      />
      <motion.div
        aria-hidden
        className="absolute -bottom-32 -right-16 w-[420px] h-[420px] rounded-full blur-3xl opacity-30"
        style={{ background: "var(--sc-accent-secondary)" }}
        initial={{ scale: 0.5, opacity: 0 }}
        animate={reduced ? {} : { scale: [0.5, 1.1, 0.7], opacity: [0, 0.28, 0.25] }}
        transition={{ duration: 10, repeat: Infinity, repeatType: "mirror" }}
      />

      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 flex items-center justify-between px-6 sm:px-10 py-5"
      >
        <div className="flex items-center gap-2">
          <Feather className="w-5 h-5" style={{ color: "var(--sc-accent-primary)" }} />
          <span className="font-serif-reader text-xl" data-testid="brand-name">Begin</span>
        </div>
        <Link
          to="/write"
          className="text-sm px-4 py-2 rounded-full border transition hover:opacity-80"
          style={{ borderColor: "var(--sc-border)", color: "var(--sc-text-primary)", background: "var(--sc-bg-sheet)" }}
          data-testid="header-enter-btn"
        >
          Enter studio
        </Link>
      </motion.header>

      {/* Hero */}
      <section className="relative z-10 px-6 sm:px-10 pt-8 sm:pt-16 pb-12 max-w-6xl mx-auto">
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.5 }}
          className="text-[11px] uppercase tracking-[0.28em] font-semibold"
          style={{ color: "var(--sc-accent-primary)" }}
          data-testid="eyebrow"
        >
          A literary studio · Autism & ADHD friendly
        </motion.p>

        <h1
          className="font-serif-reader mt-4 text-4xl sm:text-5xl lg:text-6xl leading-[1.1] max-w-3xl"
          style={{ color: "var(--sc-text-primary)" }}
          data-testid="hero-headline"
        >
          <span>{typed}</span>
          {!reduced && typed.length < FULL_TAGLINE.length && (
            <motion.span
              aria-hidden
              className="inline-block w-[2px] h-[0.9em] align-baseline ml-1"
              style={{ background: "var(--sc-accent-primary)" }}
              animate={{ opacity: [1, 0, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
          )}
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.2, duration: 0.6 }}
          className="mt-5 max-w-2xl text-base sm:text-lg leading-relaxed"
          style={{ color: "var(--sc-text-secondary)" }}
        >
          Long-form fiction with a literary collaborator that treats explicit content as craft, a
          character-evolution tracker that follows every shift, and a sensory-safe canvas designed
          for neurodivergent minds. Autosaved from the very first keystroke.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.5, duration: 0.6 }}
          className="mt-8 flex flex-wrap items-center gap-3"
        >
          <Link
            to="/write"
            className="group inline-flex items-center gap-2 px-6 py-3 rounded-full font-medium transition hover:translate-x-0.5"
            style={{ background: "var(--sc-accent-primary)", color: "var(--sc-bg-sheet)" }}
            data-testid="begin-writing-btn"
          >
            Begin writing
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
          </Link>
          <button
            type="button"
            onClick={startAsGuest}
            disabled={guestBusy}
            className="text-sm underline disabled:opacity-40"
            style={{ color: "var(--sc-text-secondary)" }}
            data-testid="about-guest-continue-btn"
          >
            {guestBusy ? "opening…" : "continue without an account"}
          </button>
          <span className="text-xs" style={{ color: "var(--sc-text-secondary)" }}>
            Free · Google sign-in or email · your words stay yours
          </span>
        </motion.div>
      </section>

      {/* Feature grid */}
      <motion.section
        variants={container}
        initial="hidden"
        animate="show"
        className="relative z-10 px-6 sm:px-10 pb-24 max-w-6xl mx-auto grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
      >
        {FEATURES.map((f, i) => (
          <motion.div
            key={f.title}
            variants={item}
            className="p-5 rounded-xl border backdrop-blur-sm"
            style={{
              background: "color-mix(in oklab, var(--sc-bg-sheet) 92%, transparent)",
              borderColor: "var(--sc-border)",
            }}
            data-testid={`feature-card-${i}`}
          >
            <div
              className="inline-flex items-center justify-center w-8 h-8 rounded-full mb-3"
              style={{ background: "var(--sc-accent-primary)", color: "var(--sc-bg-sheet)" }}
            >
              {f.icon}
            </div>
            <h3 className="font-serif-reader text-lg" style={{ color: "var(--sc-text-primary)" }}>
              {f.title}
            </h3>
            <p className="text-sm mt-1 leading-relaxed" style={{ color: "var(--sc-text-secondary)" }}>
              {f.body}
            </p>
          </motion.div>
        ))}
      </motion.section>

      <footer
        className="relative z-10 px-6 sm:px-10 py-6 border-t text-xs"
        style={{ borderColor: "var(--sc-border)", color: "var(--sc-text-secondary)" }}
      >
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <span>Begin · Sensory-safe writing sanctuary</span>
          <Link
            to="/write"
            className="underline underline-offset-4"
            data-testid="footer-enter-btn"
            style={{ color: "var(--sc-accent-primary)" }}
          >
            Open the studio →
          </Link>
        </div>
      </footer>
    </div>
  );
}
